// Modern UI Redesign for Motor Control (Based on hmi-i2r04-hmi concept)
// Preserves Tab 3 content, LightMeter, and Button Mutual Exclusion logic
#include "NotoSansKR_20.h"
#include "hardware/watchdog.h"
#include "lv_qrcode.hpp"
#include "qrcodegen.hpp"
#include <ArduinoJson.h>
#include <BH1750.h>
#include <TFT_eSPI.h>
#include <Wire.h>
#include <lvgl.h>

#define SCREEN_WIDTH 480
#define SCREEN_HEIGHT 320

// --- Modern Color Palette ---
#define COL_BG lv_color_hex(0x111827)
#define COL_PANEL lv_color_hex(0x1F2937)
#define COL_PRIMARY lv_color_hex(0x3B82F6)
#define COL_SUCCESS lv_color_hex(0x10B981)
#define COL_OFF lv_color_hex(0x4B5563)
#define COL_TXT_MAIN lv_color_hex(0xF3F4F6)
#define COL_TXT_SUB lv_color_hex(0x9CA3AF)

TFT_eSPI tft = TFT_eSPI();
static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf1[SCREEN_WIDTH * SCREEN_HEIGHT / 10];

// Global UI Objects
lv_obj_t *btn[8];
bool btnState[8] = {false};
bool ledState[8] = {false};
lv_obj_t *in_led[8];
String serialBuffer = "";
unsigned long lastSerialTime = 0;
const unsigned long serialTimeoutMs = 7000;

// Motor Specific
BH1750 lightMeter;
unsigned long lastLightSendTime = 0;
lv_obj_t *lightLabel;

lv_obj_t *ssid_ta;
lv_obj_t *pw_ta;
lv_obj_t *email_ta;
lv_obj_t *mqtt_ta;
lv_obj_t *connect_btn;
lv_obj_t *tab2;
lv_obj_t *tab3;
lv_obj_t *manual_btn;
lv_obj_t *qr_panel;
lv_obj_t *bt_btn;
lv_obj_t *fw_btn;

lv_obj_t *wifi_icon;
lv_obj_t *mqtt_icon;
lv_obj_t *mac_label;
lv_obj_t *time_label;

// --- Styles ---
static lv_style_t style_base;
static lv_style_t style_panel;
static lv_style_t style_btn_default;
static lv_style_t style_btn_checked;
static lv_style_t style_led_on;
static lv_style_t style_led_off;
static lv_style_t style_ta;

void init_styles() {
  lv_style_init(&style_base);
  lv_style_set_bg_color(&style_base, COL_BG);
  lv_style_set_text_color(&style_base, COL_TXT_MAIN);
  lv_style_set_text_font(&style_base, &NotoSansKR_20);

  lv_style_init(&style_panel);
  lv_style_set_bg_color(&style_panel, COL_PANEL);
  lv_style_set_radius(&style_panel, 12);
  lv_style_set_border_width(&style_panel, 0);
  lv_style_set_shadow_width(&style_panel, 20);
  lv_style_set_shadow_color(&style_panel, lv_color_black());
  lv_style_set_shadow_opa(&style_panel, LV_OPA_30);

  lv_style_init(&style_btn_default);
  lv_style_set_bg_color(&style_btn_default, COL_OFF);
  lv_style_set_bg_grad_color(&style_btn_default, lv_color_lighten(COL_OFF, 20));
  lv_style_set_bg_grad_dir(&style_btn_default, LV_GRAD_DIR_VER);
  lv_style_set_radius(&style_btn_default, 8);
  lv_style_set_shadow_width(&style_btn_default, 10);
  lv_style_set_shadow_color(&style_btn_default, lv_color_black());
  lv_style_set_shadow_opa(&style_btn_default, LV_OPA_40);
  lv_style_set_border_width(&style_btn_default, 2);
  lv_style_set_border_color(&style_btn_default, lv_color_white());

  lv_style_init(&style_btn_checked);
  lv_style_set_bg_color(&style_btn_checked, COL_PRIMARY);
  lv_style_set_bg_grad_color(&style_btn_checked,
                             lv_color_lighten(COL_PRIMARY, 20));
  lv_style_set_bg_grad_dir(&style_btn_checked, LV_GRAD_DIR_VER);
  lv_style_set_border_width(&style_btn_checked, 2);
  lv_style_set_border_color(&style_btn_checked, lv_color_white());
  lv_style_set_shadow_color(&style_btn_checked, COL_PRIMARY);
  lv_style_set_shadow_width(&style_btn_checked, 15);

  lv_style_init(&style_led_on);
  lv_style_set_bg_color(&style_led_on, COL_SUCCESS);
  lv_style_set_shadow_color(&style_led_on, COL_SUCCESS);
  lv_style_set_shadow_width(&style_led_on, 15);
  lv_style_set_shadow_spread(&style_led_on, 2);

  lv_style_init(&style_led_off);
  lv_style_set_bg_color(&style_led_off, COL_OFF);
  lv_style_set_shadow_width(&style_led_off, 0);

  lv_style_init(&style_ta);
  lv_style_set_bg_color(&style_ta, lv_color_darken(COL_PANEL, 10));
  lv_style_set_border_color(&style_ta, COL_OFF);
  lv_style_set_border_width(&style_ta, 1);
  lv_style_set_radius(&style_ta, 6);
  lv_style_set_text_color(&style_ta, COL_TXT_MAIN);
}

// --- Logic Functions ---

void send_bleboot() {
  JsonDocument doc;
  doc["c"] = "ti";
  doc["bleboot"] = 1;
  String json;
  serializeJson(doc, json);
  Serial1.println(json);
}

void updateInputLedUI(uint8_t index, bool state) {
  if (index >= 8)
    return;
  if (!in_led[index])
    return;

  if (state) {
    lv_obj_add_style(in_led[index], &style_led_on, LV_PART_MAIN);
    lv_obj_remove_style(in_led[index], &style_led_off, LV_PART_MAIN);
  } else {
    lv_obj_add_style(in_led[index], &style_led_off, LV_PART_MAIN);
    lv_obj_remove_style(in_led[index], &style_led_on, LV_PART_MAIN);
  }
}

void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area,
                   lv_color_t *color_p) {
  uint32_t w = area->x2 - area->x1 + 1;
  uint32_t h = area->y2 - area->y1 + 1;
  tft.startWrite();
  tft.setAddrWindow(area->x1, area->y1, w, h);
  tft.pushColors((uint16_t *)&color_p->full, w * h, true);
  tft.endWrite();
  lv_disp_flush_ready(disp);
}

uint16_t touchX, touchY;
void my_touchpad_read(lv_indev_drv_t *indev_driver, lv_indev_data_t *data) {
  bool touched = tft.getTouch(&touchX, &touchY, 600);
  data->state = touched ? LV_INDEV_STATE_PR : LV_INDEV_STATE_REL;
  if (touched) {
    data->point.x = touchX;
    data->point.y = touchY;
  }
}

void sendToggleCommand(uint8_t btnIndex, bool state) {
  JsonDocument doc;
  doc["c"] = "so";
  doc["n"] = btnIndex;
  doc["v"] = state ? 1 : 0;
  String json;
  serializeJson(doc, json);
  Serial1.println(json);
}

void updateButtonUI(uint8_t index, bool state) {
  if (index >= 8)
    return;
  if (state) {
    lv_obj_add_style(btn[index], &style_btn_checked, LV_PART_MAIN);
    lv_obj_remove_style(btn[index], &style_btn_default, LV_PART_MAIN);
  } else {
    lv_obj_remove_style(btn[index], &style_btn_checked, LV_PART_MAIN);
    lv_obj_add_style(btn[index], &style_btn_default, LV_PART_MAIN);
  }
}

void btn_event_cb(lv_event_t *e) {
  uint8_t index = (uint32_t)lv_event_get_user_data(e);

  // Mutual Exclusion Logic (from motor code)
  uint8_t other = (index % 2 == 0) ? index + 1 : index - 1;

  btnState[index] = !btnState[index];
  updateButtonUI(index, btnState[index]);
  sendToggleCommand(index, btnState[index]);

  if (btnState[index] && btnState[other]) {
    btnState[other] = false;
    updateButtonUI(other, false);
    sendToggleCommand(other, false);
  }
}

void show_qr_panel(const char *url, lv_obj_t *parent); // Forward declaration

// --- UI Creation ---

void create_tabs() {
  init_styles();

  lv_obj_t *tabview = lv_tabview_create(lv_scr_act(), LV_DIR_TOP, 45);
  lv_obj_add_style(tabview, &style_base, LV_PART_MAIN);

  lv_obj_t *tab_btns = lv_tabview_get_tab_btns(tabview);
  lv_obj_set_style_bg_color(tab_btns, COL_PANEL, LV_PART_MAIN);
  lv_obj_set_style_text_color(tab_btns, lv_color_white(), LV_PART_MAIN);
  lv_obj_set_style_text_color(tab_btns, COL_PRIMARY,
                              LV_PART_ITEMS | LV_STATE_CHECKED);
  lv_obj_set_style_border_side(tab_btns, LV_BORDER_SIDE_BOTTOM,
                               LV_PART_ITEMS | LV_STATE_CHECKED);
  lv_obj_set_style_border_color(tab_btns, COL_PRIMARY,
                                LV_PART_ITEMS | LV_STATE_CHECKED);
  lv_obj_set_style_border_width(tab_btns, 3, LV_PART_ITEMS | LV_STATE_CHECKED);
  lv_obj_set_style_text_font(tab_btns, &NotoSansKR_20, LV_PART_MAIN);

  lv_obj_t *tab1 = lv_tabview_add_tab(tabview, "모터제어");
  tab2 = lv_tabview_add_tab(tabview, "크라우드연결");
  tab3 = lv_tabview_add_tab(tabview, "사용자 메뉴얼");

  lv_obj_set_style_bg_color(tab1, COL_BG, LV_PART_MAIN);
  lv_obj_set_style_bg_color(tab2, COL_BG, LV_PART_MAIN);
  lv_obj_set_style_bg_color(tab3, COL_BG, LV_PART_MAIN);

  lv_obj_clear_flag(tab1, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clear_flag(tab2, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clear_flag(tab3, LV_OBJ_FLAG_SCROLLABLE);

  // --- Tab 1: Dashboard (Control) ---

  // Section: Input Status (Glass Panel)
  lv_obj_t *panel_in = lv_obj_create(tab1);
  lv_obj_set_size(panel_in, 460, 70);
  lv_obj_align(panel_in, LV_ALIGN_TOP_MID, 0, -10);
  lv_obj_add_style(panel_in, &style_panel, LV_PART_MAIN);
  lv_obj_clear_flag(panel_in, LV_OBJ_FLAG_SCROLLABLE);

  for (int i = 0; i < 8; i++) {
    in_led[i] = lv_obj_create(panel_in);
    lv_obj_set_size(in_led[i], 36, 36);
    lv_obj_set_style_radius(in_led[i], LV_RADIUS_CIRCLE, LV_PART_MAIN);

    // Evenly distribute 8 LEDs
    int x_pos = 15 + (i * 53);
    lv_obj_align(in_led[i], LV_ALIGN_LEFT_MID, x_pos, 0);

    lv_obj_add_style(in_led[i], &style_led_off, LV_PART_MAIN);

    // Label Number
    lv_obj_t *led_num = lv_label_create(in_led[i]);
    lv_label_set_text_fmt(led_num, "%d", i + 1);
    lv_obj_set_style_text_color(led_num, lv_color_white(), 0);
    lv_obj_center(led_num);
  }

  // Section: Output Control
  lv_obj_t *panel_out = lv_obj_create(tab1);
  lv_obj_set_size(panel_out, 460, 160);
  lv_obj_align(panel_out, LV_ALIGN_TOP_MID, 0, 55);
  lv_obj_add_style(panel_out, &style_panel, LV_PART_MAIN);
  lv_obj_clear_flag(panel_out, LV_OBJ_FLAG_SCROLLABLE);

  for (int i = 0; i < 8; i++) {
    btn[i] = lv_btn_create(tab1);
    lv_obj_set_size(btn[i], 90, 60);

    // Vertical Pairing Layout:
    // Row 0: 0, 2, 4, 6 (Top)
    // Row 1: 1, 3, 5, 7 (Bottom)
    int row = i % 2; // 0(Even)=Top, 1(Odd)=Bottom
    int col = i / 2; // 0, 1, 2, 3

    int x_pos = 30 + (col * 105);
    int y_pos = 55 + (row * 75);

    lv_obj_align(btn[i], LV_ALIGN_TOP_LEFT, x_pos, y_pos);

    lv_obj_add_style(btn[i], &style_btn_default, LV_PART_MAIN);
    lv_obj_add_event_cb(btn[i], btn_event_cb, LV_EVENT_CLICKED,
                        (void *)(uintptr_t)i);

    // Label with Logic Number
    lv_obj_t *label = lv_label_create(btn[i]);
    // i=0,1 -> 1 / i=2,3 -> 2 ...
    lv_label_set_text_fmt(label, "%d", (i / 2) + 1);
    lv_obj_set_style_text_font(label, &NotoSansKR_20, 0);
    lv_obj_center(label);
  }

  // Status Icons
  wifi_icon = lv_label_create(tab1);
  lv_label_set_text(wifi_icon, LV_SYMBOL_WIFI);
  lv_obj_set_style_text_font(wifi_icon, &lv_font_montserrat_20, LV_PART_MAIN);
  lv_obj_set_style_text_color(wifi_icon, COL_OFF, LV_PART_MAIN);
  lv_obj_align(wifi_icon, LV_ALIGN_BOTTOM_LEFT, 20, -10);

  mqtt_icon = lv_label_create(tab1);
  lv_label_set_text(mqtt_icon, LV_SYMBOL_REFRESH);
  lv_obj_set_style_text_font(mqtt_icon, &lv_font_montserrat_20, LV_PART_MAIN);
  lv_obj_set_style_text_color(mqtt_icon, COL_OFF, LV_PART_MAIN);
  lv_obj_align(mqtt_icon, LV_ALIGN_BOTTOM_LEFT, 60, -10);

  // Light Level Label (Motor Specific)
  lightLabel = lv_label_create(tab1);
  lv_label_set_text(lightLabel, "조도 --");
  lv_obj_set_style_text_font(lightLabel, &NotoSansKR_20, LV_PART_MAIN);
  lv_obj_set_style_text_color(lightLabel, COL_TXT_MAIN, LV_PART_MAIN);
  lv_obj_align(lightLabel, LV_ALIGN_BOTTOM_RIGHT, -15, -10);

  // Time Label
  time_label = lv_label_create(tab1);
  lv_label_set_text(time_label, "--:--");
  lv_obj_set_style_text_font(time_label, &lv_font_montserrat_20, LV_PART_MAIN);
  lv_obj_set_style_text_color(time_label, lv_color_white(),
                              LV_PART_MAIN); // Changed to White (like ADC)
  lv_obj_align(time_label, LV_ALIGN_BOTTOM_LEFT, 100, -10);

  // --- Tab 2: Settings / Connection ---

  lv_obj_t *panel_set = lv_obj_create(tab2);
  lv_obj_set_size(panel_set, 440, 260);
  lv_obj_center(panel_set);
  lv_obj_add_style(panel_set, &style_panel, LV_PART_MAIN);
  lv_obj_set_style_bg_opa(panel_set, LV_OPA_0, LV_PART_MAIN);
  lv_obj_set_style_border_width(panel_set, 0, LV_PART_MAIN);
  lv_obj_clear_flag(panel_set, LV_OBJ_FLAG_SCROLLABLE);

  lv_obj_t *form_cont = lv_obj_create(panel_set);
  lv_obj_set_size(form_cont, 420, 180);
  lv_obj_align(form_cont, LV_ALIGN_TOP_MID, 0, 0);
  lv_obj_add_style(form_cont, &style_panel, LV_PART_MAIN);

  ssid_ta = lv_textarea_create(form_cont);
  lv_obj_set_width(ssid_ta, 190);
  lv_textarea_set_one_line(ssid_ta, true);
  lv_textarea_set_placeholder_text(ssid_ta, "와이파이 이름");
  lv_obj_add_style(ssid_ta, &style_ta, LV_PART_MAIN);
  lv_obj_align(ssid_ta, LV_ALIGN_TOP_LEFT, 0, 0);

  pw_ta = lv_textarea_create(form_cont);
  lv_obj_set_width(pw_ta, 190);
  lv_textarea_set_one_line(pw_ta, true);
  lv_textarea_set_password_mode(pw_ta, true);
  lv_textarea_set_placeholder_text(pw_ta, "비밀번호");
  lv_obj_add_style(pw_ta, &style_ta, LV_PART_MAIN);
  lv_obj_align(pw_ta, LV_ALIGN_TOP_RIGHT, 0, 0);

  email_ta = lv_textarea_create(form_cont);
  lv_obj_set_size(email_ta, 190, 40);
  lv_textarea_set_one_line(email_ta, true);
  lv_textarea_set_placeholder_text(email_ta, "이메일");
  lv_obj_add_style(email_ta, &style_ta, LV_PART_MAIN);
  lv_obj_align(email_ta, LV_ALIGN_TOP_LEFT, 0, 50);

  mqtt_ta = lv_textarea_create(form_cont);
  lv_obj_set_size(mqtt_ta, 190, 40);
  lv_textarea_set_one_line(mqtt_ta, true);
  lv_textarea_set_placeholder_text(mqtt_ta, "MQTT 주소");
  lv_textarea_set_text(mqtt_ta, "mqtt.i2r.link");
  lv_obj_add_style(mqtt_ta, &style_ta, LV_PART_MAIN);
  lv_obj_align(mqtt_ta, LV_ALIGN_TOP_RIGHT, 0, 50);

  lv_obj_t *act_row = lv_obj_create(panel_set);
  lv_obj_set_size(act_row, 420, 60);
  lv_obj_align(act_row, LV_ALIGN_BOTTOM_MID, 0, 0);
  lv_obj_set_style_bg_opa(act_row, LV_OPA_TRANSP, LV_PART_MAIN);
  lv_obj_set_style_border_width(act_row, 0, LV_PART_MAIN);
  lv_obj_set_flex_flow(act_row, LV_FLEX_FLOW_ROW);
  lv_obj_set_flex_align(act_row, LV_FLEX_ALIGN_SPACE_BETWEEN,
                        LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
  lv_obj_clear_flag(act_row, LV_OBJ_FLAG_SCROLLABLE);

  manual_btn = lv_btn_create(act_row);
  lv_obj_set_size(manual_btn, 100, 40);
  lv_obj_add_style(manual_btn, &style_btn_default, LV_PART_MAIN);
  lv_obj_t *l1 = lv_label_create(manual_btn);
  lv_label_set_text(l1, "사용법 보기");
  lv_obj_center(l1);

  connect_btn = lv_btn_create(act_row);
  lv_obj_set_size(connect_btn, 100, 40);
  lv_obj_add_style(connect_btn, &style_btn_checked, LV_PART_MAIN);
  lv_obj_t *l2 = lv_label_create(connect_btn);
  lv_label_set_text(l2, "연결");
  lv_obj_center(l2);

  bt_btn = lv_btn_create(act_row);
  lv_obj_set_size(bt_btn, 100, 40);
  lv_obj_add_style(bt_btn, &style_btn_default, LV_PART_MAIN);
  lv_obj_t *l3 = lv_label_create(bt_btn);
  lv_label_set_text(l3, "블루투스");
  lv_obj_center(l3);

  fw_btn = lv_btn_create(act_row);
  lv_obj_set_size(fw_btn, 80, 40);
  lv_obj_add_style(fw_btn, &style_btn_default, LV_PART_MAIN);
  lv_obj_t *l4 = lv_label_create(fw_btn);
  lv_label_set_text(l4, "펌웨어");
  lv_obj_center(l4);

  mac_label = lv_label_create(form_cont);
  lv_label_set_text(mac_label, "MAC: ----");
  lv_obj_set_style_text_color(mac_label, COL_TXT_SUB, 0);
  lv_obj_align(mac_label, LV_ALIGN_BOTTOM_LEFT, 0, -10);

  // Events
  auto qr_event = [](lv_event_t *e) {
    show_qr_panel("https://youtu.be/eMnKAh1EjlE", tab2);
  };
  lv_obj_add_event_cb(manual_btn, qr_event, LV_EVENT_CLICKED, NULL);

  lv_obj_add_event_cb(
      connect_btn,
      [](lv_event_t *e) {
        const char *email = lv_textarea_get_text(email_ta);
        const char *ssid = lv_textarea_get_text(ssid_ta);
        const char *password = lv_textarea_get_text(pw_ta);
        const char *mqtt = lv_textarea_get_text(mqtt_ta);
        JsonDocument doc;
        doc["c"] = "si";
        doc["e"] = email;
        doc["ssid"] = ssid;
        doc["password"] = password;
        doc["mqttBroker"] = mqtt;
        String json;
        serializeJson(doc, json);
        Serial1.println(json);
      },
      LV_EVENT_CLICKED, NULL);

  lv_obj_add_event_cb(
      bt_btn, [](lv_event_t *e) { send_bleboot(); }, LV_EVENT_CLICKED, NULL);

  lv_obj_add_event_cb(
      fw_btn,
      [](lv_event_t *e) {
        JsonDocument doc;
        doc["c"] = "df";
        doc["f"] = "i2r-04-motor.ino.bin";
        String json;
        serializeJson(doc, json);
        Serial1.println(json);
      },
      LV_EVENT_CLICKED, NULL);

  // Keyboard
  lv_obj_t *kb = lv_keyboard_create(tab2);
  lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);
  lv_obj_align(kb, LV_ALIGN_BOTTOM_MID, 0, 0);
  lv_obj_set_style_text_font(kb, &lv_font_montserrat_20, LV_PART_MAIN);

  auto kb_event_cb = [](lv_event_t *e) {
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t *ta = lv_event_get_target(e);
    lv_obj_t *kb = (lv_obj_t *)lv_event_get_user_data(e);
    if (code == LV_EVENT_FOCUSED || code == LV_EVENT_CLICKED) {
      lv_keyboard_set_textarea(kb, ta);
      lv_obj_clear_flag(kb, LV_OBJ_FLAG_HIDDEN);
      lv_obj_add_flag(connect_btn, LV_OBJ_FLAG_HIDDEN);
      lv_obj_add_flag(manual_btn, LV_OBJ_FLAG_HIDDEN);
      lv_obj_add_flag(bt_btn, LV_OBJ_FLAG_HIDDEN);
      lv_obj_add_flag(fw_btn, LV_OBJ_FLAG_HIDDEN);
      if (mac_label)
        lv_obj_add_flag(mac_label, LV_OBJ_FLAG_HIDDEN);
    }
  };
  lv_obj_add_event_cb(ssid_ta, kb_event_cb, LV_EVENT_ALL, kb);
  lv_obj_add_event_cb(pw_ta, kb_event_cb, LV_EVENT_ALL, kb);
  lv_obj_add_event_cb(email_ta, kb_event_cb, LV_EVENT_ALL, kb);
  lv_obj_add_event_cb(mqtt_ta, kb_event_cb, LV_EVENT_ALL, kb);

  lv_obj_add_event_cb(
      kb,
      [](lv_event_t *e) {
        lv_event_code_t code = lv_event_get_code(e);
        lv_obj_t *kb = lv_event_get_target(e);
        if (code == LV_EVENT_CANCEL || code == LV_EVENT_READY) {
          lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);
          lv_obj_clear_flag(connect_btn, LV_OBJ_FLAG_HIDDEN);
          lv_obj_clear_flag(manual_btn, LV_OBJ_FLAG_HIDDEN);
          lv_obj_clear_flag(bt_btn, LV_OBJ_FLAG_HIDDEN);
          lv_obj_clear_flag(fw_btn, LV_OBJ_FLAG_HIDDEN);
          if (mac_label)
            lv_obj_clear_flag(mac_label, LV_OBJ_FLAG_HIDDEN);
        }
      },
      LV_EVENT_ALL, NULL);

  // --- Tab 3: Manuals (Identical to hmi-i2r04-hmi) ---
  lv_obj_t *list_cont = lv_obj_create(tab3);
  lv_obj_set_size(list_cont, 440, 260);
  lv_obj_center(list_cont);
  lv_obj_add_style(list_cont, &style_panel, LV_PART_MAIN);
  lv_obj_set_flex_flow(list_cont, LV_FLEX_FLOW_ROW_WRAP);
  lv_obj_set_style_pad_gap(list_cont, 15, 0);

  const char *titles[] = {"기기연결/로그인",  "타이머 설정",   "입력 트리거",
                          "센서 트리거",      "Github 메뉴얼", "아이티알 홈",
                          "HMI 한글폰트 설치"};
  const char *urls[] = {
      "https://youtu.be/o17IrUawetg",
      "https://youtu.be/hlbH4OiEDu4",
      "https://youtu.be/e6tqkVcQ8n0",
      "https://youtu.be/hOzujluNKDU",
      "https://github.com/kdi6033/i2r-04/blob/main/README.md#i2r-04-motor",
      "https://i2r.link",
      "https://github.com/kdi6033/"
      "i2r#4-lvgl-%ED%95%9C%EA%B8%80-%ED%8F%B0%ED%8A%B8-%EC%A0%81%EC%9A%A9-%EA%"
      "B0%80%EC%9D%B4%EB%93%9C"};

  for (int i = 0; i < 7; i++) {
    lv_obj_t *btn_link = lv_btn_create(list_cont);
    lv_obj_set_width(btn_link, 190);
    lv_obj_add_style(btn_link, &style_btn_default, LV_PART_MAIN);
    lv_obj_t *l = lv_label_create(btn_link);
    lv_label_set_text(l, titles[i]);
    lv_obj_center(l);

    lv_obj_add_event_cb(
        btn_link,
        [](lv_event_t *e) {
          const char *url = (const char *)lv_event_get_user_data(e);
          show_qr_panel(url, tab3);
        },
        LV_EVENT_CLICKED, (void *)urls[i]);
  }
}

// QR Panel Implementation
void show_qr_panel(const char *url, lv_obj_t *parent) {
  if (qr_panel)
    lv_obj_del(qr_panel);

  qr_panel = lv_obj_create(parent);
  lv_obj_set_size(qr_panel, 400, 240);
  lv_obj_center(qr_panel);
  lv_obj_set_style_bg_color(qr_panel, COL_BG, LV_PART_MAIN);
  lv_obj_set_style_border_color(qr_panel, COL_PRIMARY, LV_PART_MAIN);
  lv_obj_set_style_border_width(qr_panel, 2, LV_PART_MAIN);
  lv_obj_set_style_radius(qr_panel, 12, LV_PART_MAIN);

  lv_obj_t *qr =
      lv_qrcode_create(qr_panel, 180, lv_color_white(), lv_color_black());
  lv_qrcode_update(qr, url, strlen(url));
  lv_obj_align(qr, LV_ALIGN_LEFT_MID, 20, 0);

  lv_obj_t *close_btn = lv_btn_create(qr_panel);
  lv_obj_set_size(close_btn, 100, 40);
  lv_obj_align(close_btn, LV_ALIGN_RIGHT_MID, -20, 0);
  lv_obj_add_style(close_btn, &style_btn_default, LV_PART_MAIN);

  lv_obj_t *l = lv_label_create(close_btn);
  lv_label_set_text(l, "닫기");
  lv_obj_center(l);

  lv_obj_add_event_cb(
      close_btn,
      [](lv_event_t *e) {
        lv_obj_del(qr_panel);
        qr_panel = NULL;
      },
      LV_EVENT_CLICKED, NULL);
}

void setup() {
  delay(1000);
  Serial.begin(115200);
  Serial1.setTX(0);
  Serial1.setRX(1);
  Serial1.begin(9600);

  Wire.setSDA(20);
  Wire.setSCL(21);
  Wire.begin();
  lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE);

  tft.begin();
  tft.setRotation(1);
  uint16_t calData[5] = {192, 3590, 335, 3362, 1};
  tft.setTouch(calData);
  tft.fillScreen(TFT_BLACK);

  lv_init();
  lv_disp_draw_buf_init(&draw_buf, buf1, NULL,
                        SCREEN_WIDTH * SCREEN_HEIGHT / 10);
  static lv_disp_drv_t disp_drv;
  lv_disp_drv_init(&disp_drv);
  disp_drv.hor_res = SCREEN_WIDTH;
  disp_drv.ver_res = SCREEN_HEIGHT;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;
  lv_disp_drv_register(&disp_drv);

  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);

  create_tabs();
  Serial1.println("INIT");
  serialBuffer.reserve(256); // 메모리 예약 최적화
}

void loop() {
  lv_timer_handler();
  delay(5);

  if (millis() - lastLightSendTime >= 3000) {
    int lux = (int)lightMeter.readLightLevel();
    JsonDocument doc;
    doc["c"] = "ti";
    doc["light"] = lux;
    String json;
    serializeJson(doc, json);
    Serial1.println(json);
    lastLightSendTime = millis();
  }

  // ✅ 시리얼 버퍼 제한 제거: 하드웨어 버퍼 오버플로우 방지
  while (Serial1.available()) {
    char c = Serial1.read();
    lastSerialTime = millis(); // 데이터 수신 시점 갱신

    if (c == '\n') {
      serialBuffer.trim();
      if (serialBuffer.length() > 0) {
        parseJSONPayload((byte *)serialBuffer.c_str(), serialBuffer.length());
      }
      serialBuffer = "";
    } else {
      if (serialBuffer.length() < 256)
        serialBuffer += c;
    }
  }
}

void parseJSONPayload(byte *payload, unsigned int length) {
  // Serial.println((const char*)payload);
  JsonDocument doc;
  DeserializationError error = deserializeJson(doc, payload, length);
  if (error)
    return;

  if (doc["c"] == "ti") {
    JsonArray outArray = doc["out"];
    for (int i = 0; i < 8 && i < outArray.size(); i++) {
      bool newState = outArray[i];
      if (btnState[i] != newState) {
        btnState[i] = newState;
        updateButtonUI(i, btnState[i]);
      }
    }
  }

  JsonArray inArray = doc["in"];
  if (!inArray.isNull()) {
    for (int i = 0; i < 8 && i < inArray.size(); i++) {
      bool newState = inArray[i];
      if (ledState[i] != newState) {
        ledState[i] = newState;
        updateInputLedUI(i, newState);
      }
    }
  }

  // Update Light Label
  int lightValue = doc["light"] | -1;
  if (lightValue >= 0 && lightLabel) {
    char buf[32];
    snprintf(buf, sizeof(buf), "조도 %d", lightValue);
    lv_label_set_text(lightLabel, buf);
  }

  bool wifiStatus = doc["wifi"] | false;
  if (wifiStatus)
    lv_obj_set_style_text_color(wifi_icon, COL_SUCCESS, 0);
  else
    lv_obj_set_style_text_color(wifi_icon, COL_OFF, 0);

  bool mqttStatus = doc["mqtt"] | false;
  if (mqttStatus)
    lv_obj_set_style_text_color(mqtt_icon, COL_SUCCESS, 0);
  else
    lv_obj_set_style_text_color(mqtt_icon, COL_OFF, 0);

  if (!doc["mac"].isNull() && mac_label) {
    const char *mac = doc["mac"];
    lv_label_set_text_fmt(mac_label, "MAC: %s", mac);
    lv_obj_align(mac_label, LV_ALIGN_BOTTOM_LEFT, 0, -10);
  }

  if (!doc["time"].isNull() && time_label) {
    const char *timeStr = doc["time"];
    lv_label_set_text(time_label, timeStr);
  }
}
