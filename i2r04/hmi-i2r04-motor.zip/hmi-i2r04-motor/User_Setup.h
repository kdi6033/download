// TFT_eSPI User_Setup - CrowPanel 3.5" ILI9488 (RP2040)
// 이 파일이 스케치 폴더에 있으면 TFT_eSPI가 이 설정을 사용합니다.
// board-i2r-03-hmi CrowPanel 3.5" 기준

#define USER_SETUP_INFO "CrowPanel 3.5 ILI9488 RP2040"

// ----- Section 1: Driver -----
#define ILI9488_DRIVER

// 3.5" 480x320 (portrait: 320x480)
#define TFT_WIDTH  320
#define TFT_HEIGHT 480

// 초기화 시 색 반전 (하얀 화면이면 TFT_INVERSION_ON으로 바꿔보기)
#define TFT_INVERSION_OFF
// #define TFT_INVERSION_ON

// ----- Section 2: Pins (RP2040 / Raspberry Pi Pico) -----
#define TFT_MISO  12
#define TFT_MOSI  11
#define TFT_SCLK  10
#define TFT_CS    9
#define TFT_DC    8
#define TFT_RST   15
#define TFT_BL    18
#define TFT_BACKLIGHT_ON HIGH
#define TOUCH_CS  16

// ----- Section 3: RP2040 SPI -----
#define TFT_SPI_PORT 1

// ----- Section 4: SPI speed (80MHz 안 되면 40000000 사용) -----
#define SPI_FREQUENCY  40000000
#define SPI_READ_FREQUENCY  20000000
#define SPI_TOUCH_FREQUENCY  2500000
