// Modern UI Redesign 2025.12.09
#include <lvgl.h>
#include <TFT_eSPI.h>
#include <Wire.h>
#include <ArduinoJson.h>
#include "lv_qrcode.hpp"
#include "qrcodegen.hpp"
#include "NotoSansKR_20.h"
#include "hardware/watchdog.h"

#define SCREEN_WIDTH 480
#define SCREEN_HEIGHT 320

// --- Modern Color Palette ---
// Background: Dark Blue-Grey #111827 (RGB: 17, 24, 39)
// Panel/Surface: #1F2937 (RGB: 31, 41, 55)
// Primary Accent: #3B82F6 (RGB: 59, 130, 246)
// Success/Active: #10B981 (RGB: 16, 185, 129)
// Text Main: #F3F4F6 (RGB: 243, 244, 246)
// Text Sub: #9CA3AF (RGB: 156, 163, 175)

#define COL_BG       lv_color_hex(0x111827)
#define COL_PANEL    lv_color_hex(0x1F2937)
#define COL_PRIMARY  lv_color_hex(0x3B82F6)
#define COL_SUCCESS  lv_color_hex(0x10B981)
#define COL_OFF      lv_color_hex(0x4B5563) // Gray
#define COL_TXT_MAIN lv_color_hex(0xF3F4F6)
#define COL_TXT_SUB  lv_color_hex(0x9CA3AF)

TFT_eSPI tft = TFT_eSPI();
static lv_disp_draw_buf_t draw_buf;
static lv_color_t buf1[SCREEN_WIDTH * SCREEN_HEIGHT / 10];

// Global UI Objects
lv_obj_t* btn[4];
bool btnState[4] = {false};
bool ledState[4] = {false};
lv_obj_t* in_led[4];
String serialBuffer = "";

lv_obj_t* ssid_ta;
lv_obj_t* pw_ta;
lv_obj_t* email_ta;
lv_obj_t* mqtt_ta;
lv_obj_t* connect_btn;
lv_obj_t* tab2;
lv_obj_t* tab3;
lv_obj_t* manual_btn;
lv_obj_t* qr_panel;
lv_obj_t* bt_btn;
lv_obj_t* fw_btn;

lv_obj_t* wifi_icon;
lv_obj_t* mqtt_icon;
lv_obj_t* mac_label;

// --- Styles ---
static lv_style_t style_base;
static lv_style_t style_panel;
static lv_style_t style_btn_default;
static lv_style_t style_btn_checked;
static lv_style_t style_led_on;
static lv_style_t style_led_off;
static lv_style_t style_ta;

void init_styles() {
    lv_style_init(&style_base);
    lv_style_set_bg_color(&style_base, COL_BG);
    lv_style_set_text_color(&style_base, COL_TXT_MAIN);
    lv_style_set_text_font(&style_base, &NotoSansKR_20);

    lv_style_init(&style_panel);
    lv_style_set_bg_color(&style_panel, COL_PANEL);
    lv_style_set_radius(&style_panel, 12);
    lv_style_set_border_width(&style_panel, 0);
    lv_style_set_shadow_width(&style_panel, 20);
    lv_style_set_shadow_color(&style_panel, lv_color_black());
    lv_style_set_shadow_opa(&style_panel, LV_OPA_30);

    lv_style_init(&style_btn_default);
    lv_style_set_bg_color(&style_btn_default, COL_OFF); // Changed from COL_PANEL to COL_OFF
    lv_style_set_bg_grad_color(&style_btn_default, lv_color_lighten(COL_OFF, 20));
    lv_style_set_bg_grad_dir(&style_btn_default, LV_GRAD_DIR_VER);
    lv_style_set_radius(&style_btn_default, 8);
    lv_style_set_shadow_width(&style_btn_default, 10);
    lv_style_set_shadow_color(&style_btn_default, lv_color_black());
    lv_style_set_shadow_opa(&style_btn_default, LV_OPA_40);
    lv_style_set_border_width(&style_btn_default, 2);
    lv_style_set_border_color(&style_btn_default, lv_color_white());

    lv_style_init(&style_btn_checked);
    lv_style_set_bg_color(&style_btn_checked, COL_PRIMARY);
    lv_style_set_bg_grad_color(&style_btn_checked, lv_color_lighten(COL_PRIMARY, 20));
    lv_style_set_bg_grad_dir(&style_btn_checked, LV_GRAD_DIR_VER);
    lv_style_set_border_width(&style_btn_checked, 2);
    lv_style_set_border_color(&style_btn_checked, lv_color_white());
    lv_style_set_shadow_color(&style_btn_checked, COL_PRIMARY);
    lv_style_set_shadow_width(&style_btn_checked, 15);

    lv_style_init(&style_led_on);
    lv_style_set_bg_color(&style_led_on, COL_SUCCESS);
    lv_style_set_shadow_color(&style_led_on, COL_SUCCESS);
    lv_style_set_shadow_width(&style_led_on, 15);
    lv_style_set_shadow_spread(&style_led_on, 2);

    lv_style_init(&style_led_off);
    lv_style_set_bg_color(&style_led_off, COL_OFF);
    lv_style_set_shadow_width(&style_led_off, 0);

    lv_style_init(&style_ta);
    lv_style_set_bg_color(&style_ta, lv_color_darken(COL_PANEL, 10));
    lv_style_set_border_color(&style_ta, COL_OFF);
    lv_style_set_border_width(&style_ta, 1);
    lv_style_set_radius(&style_ta, 6);
    lv_style_set_text_color(&style_ta, COL_TXT_MAIN);
}

// --- Logic Functions ---

void send_bleboot() {
  JsonDocument doc;
  doc["c"] = "ti";
  doc["bleboot"] = 1;
  String json;
  serializeJson(doc, json);
  Serial1.println(json);
  Serial.println("[SEND] " + json);
}

void updateInputLedUI(uint8_t index, bool state) {
  if (index >= 4) return;
  if(state) {
      lv_obj_add_style(in_led[index], &style_led_on, LV_PART_MAIN);
      lv_obj_remove_style(in_led[index], &style_led_off, LV_PART_MAIN);
  } else {
      lv_obj_add_style(in_led[index], &style_led_off, LV_PART_MAIN);
      lv_obj_remove_style(in_led[index], &style_led_on, LV_PART_MAIN);
  }
}

void my_disp_flush(lv_disp_drv_t* disp, const lv_area_t* area, lv_color_t* color_p) {
  uint32_t w = area->x2 - area->x1 + 1;
  uint32_t h = area->y2 - area->y1 + 1;
  tft.startWrite();
  tft.setAddrWindow(area->x1, area->y1, w, h);
  tft.pushColors((uint16_t*)&color_p->full, w * h, true);
  tft.endWrite();
  lv_disp_flush_ready(disp);
}

uint16_t touchX, touchY;
void my_touchpad_read(lv_indev_drv_t* indev_driver, lv_indev_data_t* data) {
  bool touched = tft.getTouch(&touchX, &touchY, 600);
  data->state = touched ? LV_INDEV_STATE_PR : LV_INDEV_STATE_REL;
  if (touched) {
    data->point.x = touchX;
    data->point.y = touchY;
  }
}

void sendToggleCommand(uint8_t btnIndex, bool state) {
  JsonDocument doc;
  doc["c"] = "so";
  doc["n"] = btnIndex;
  doc["v"] = state ? 1 : 0;
  String json;
  serializeJson(doc, json);
  Serial1.println(json);
  Serial.println("[SEND-toggle] " + json);
}

// updateButtonUI: Label text remains static (numbers), only style changes
void updateButtonUI(uint8_t index, bool state) {
  if(state) {
    lv_obj_add_style(btn[index], &style_btn_checked, LV_PART_MAIN);
    // Removed text toggle "ON"/"OFF"
  } else {
    lv_obj_remove_style(btn[index], &style_btn_checked, LV_PART_MAIN);
    lv_obj_add_style(btn[index], &style_btn_default, LV_PART_MAIN);
    // Removed text toggle "ON"/"OFF"
  }
}

void btn_event_cb(lv_event_t* e) {
  uint8_t index = (uint32_t)lv_event_get_user_data(e);
  btnState[index] = !btnState[index];
  updateButtonUI(index, btnState[index]);
  sendToggleCommand(index, btnState[index]);
}

void show_qr_panel(const char* url, lv_obj_t* parent); // Forward declaration

// --- UI Creation ---

void create_header(lv_obj_t* parent, const char* title) {
    // Simple Header if needed, or rely on TabView buttons
    // Currently TabView handles titles.
}

void add_footer_label(lv_obj_t* parent) {
  lv_obj_t* footer = lv_label_create(parent);
  lv_label_set_text(footer, "아이티알 i2r.link");
  lv_obj_set_style_text_color(footer, lv_color_hex(0xFF7518), LV_PART_MAIN); // Pumpkin Orange
  lv_obj_align(footer, LV_ALIGN_BOTTOM_RIGHT, -10, -5);
}

void create_tabs() {
  init_styles();

  // 1. Tabview with modern styling
  lv_obj_t* tabview = lv_tabview_create(lv_scr_act(), LV_DIR_TOP, 45);
  lv_obj_add_style(tabview, &style_base, LV_PART_MAIN);

  lv_obj_t* tab_btns = lv_tabview_get_tab_btns(tabview);
  lv_obj_set_style_bg_color(tab_btns, COL_PANEL, LV_PART_MAIN);
  lv_obj_set_style_text_color(tab_btns, lv_color_white(), LV_PART_MAIN);
  lv_obj_set_style_text_color(tab_btns, COL_PRIMARY, LV_PART_ITEMS | LV_STATE_CHECKED); // Active tab color
  lv_obj_set_style_border_side(tab_btns, LV_BORDER_SIDE_BOTTOM, LV_PART_ITEMS | LV_STATE_CHECKED);
  lv_obj_set_style_border_color(tab_btns, COL_PRIMARY, LV_PART_ITEMS | LV_STATE_CHECKED);
  lv_obj_set_style_border_width(tab_btns, 3, LV_PART_ITEMS | LV_STATE_CHECKED);
  lv_obj_set_style_text_font(tab_btns, &NotoSansKR_20, LV_PART_MAIN);

  lv_obj_t* tab1 = lv_tabview_add_tab(tabview, "제어판");
  tab2 = lv_tabview_add_tab(tabview, "설정");
  tab3 = lv_tabview_add_tab(tabview, "메뉴얼");

  lv_obj_set_style_bg_color(tab1, COL_BG, LV_PART_MAIN);
  lv_obj_set_style_bg_color(tab2, COL_BG, LV_PART_MAIN);
  lv_obj_set_style_bg_color(tab3, COL_BG, LV_PART_MAIN);

  // Prevent scrolling on tabs
  lv_obj_clear_flag(tab1, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clear_flag(tab2, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clear_flag(tab3, LV_OBJ_FLAG_SCROLLABLE);

  // --- Tab 1: Dashboard (Control) ---
  
  // Section: Input Status (Glass Panel)
  lv_obj_t* panel_in = lv_obj_create(tab1);
  lv_obj_set_size(panel_in, 445, 80); // Reduced width 450 -> 430
  lv_obj_align(panel_in, LV_ALIGN_TOP_MID, 0, 10);
  lv_obj_add_style(panel_in, &style_panel, LV_PART_MAIN);
  lv_obj_clear_flag(panel_in, LV_OBJ_FLAG_SCROLLABLE);

  // Removed "입력 상태" label

  for (int i = 0; i < 4; i++) {
    in_led[i] = lv_obj_create(panel_in);
    lv_obj_set_size(in_led[i], 45, 45); // Reduced size 60 -> 45
    lv_obj_set_style_radius(in_led[i], LV_RADIUS_CIRCLE, LV_PART_MAIN);
    
    // Distribute: Start 45, Step 100.
    // 45 + 300 = 345. Width 45. Right edge 390. Center perfectly?
    // 450 width. 4 items. Center spacing.
    // Let's keep previous logic but maybe shift X slightly if needed.
    // 45+(0)=45. 45+300=345.
    int x_pos = 50 + (i * 100); 
    lv_obj_align(in_led[i], LV_ALIGN_LEFT_MID, x_pos, 0);

    // Initial Style (OFF)
    lv_obj_add_style(in_led[i], &style_led_off, LV_PART_MAIN);

    // Label Number INSIDE LED
    lv_obj_t* led_num = lv_label_create(in_led[i]);
    lv_label_set_text_fmt(led_num, "%d", i + 1); // 1, 2, 3, 4
    lv_obj_set_style_text_color(led_num, lv_color_white(), 0);
    lv_obj_center(led_num);
  }

  // Section: Output Control (Bottom Area)
  lv_obj_t* panel_out = lv_obj_create(tab1);
  lv_obj_set_size(panel_out, 445, 150); // Matched width with panel_in
  lv_obj_align(panel_out, LV_ALIGN_TOP_MID, 0, 100); // 10px gap below panel_in
  lv_obj_add_style(panel_out, &style_panel, LV_PART_MAIN);
  lv_obj_clear_flag(panel_out, LV_OBJ_FLAG_SCROLLABLE);

  // Removed "출력 제어" label

  for (int i = 0; i < 4; i++) {
    btn[i] = lv_btn_create(panel_out);
    lv_obj_set_size(btn[i], 90, 70); 
    
    // Distribute: Start 28, Step 100 to align center with LEDs (72.5 center)
    // 27.5 + 45 = 72.5
    int x_pos = 28 + (i * 100);
    lv_obj_align(btn[i], LV_ALIGN_LEFT_MID, x_pos, -25); // Restored to original relative position (compensated for panel height)
    
    lv_obj_add_style(btn[i], &style_btn_default, LV_PART_MAIN);
    lv_obj_add_event_cb(btn[i], btn_event_cb, LV_EVENT_CLICKED, (void*)(uintptr_t)i);

    lv_obj_t* label = lv_label_create(btn[i]);
    lv_label_set_text_fmt(label, "%d", i + 1); // 1, 2, 3, 4
    lv_obj_set_style_text_font(label, &NotoSansKR_20, 0);
    lv_obj_center(label);
  }

  // Footer / Status Icons
  wifi_icon = lv_label_create(tab1);
  lv_label_set_text(wifi_icon, LV_SYMBOL_WIFI);
  lv_obj_set_style_text_font(wifi_icon, &lv_font_montserrat_20, LV_PART_MAIN);
  lv_obj_set_style_text_color(wifi_icon, COL_OFF, LV_PART_MAIN); 
  lv_obj_align(wifi_icon, LV_ALIGN_BOTTOM_LEFT, 20, -10);

  mqtt_icon = lv_label_create(tab1);
  lv_label_set_text(mqtt_icon, LV_SYMBOL_REFRESH);
  lv_obj_set_style_text_font(mqtt_icon, &lv_font_montserrat_20, LV_PART_MAIN);
  lv_obj_set_style_text_color(mqtt_icon, COL_OFF, LV_PART_MAIN); 
  lv_obj_align(mqtt_icon, LV_ALIGN_BOTTOM_LEFT, 60, -10);

  add_footer_label(tab1);


  // --- Tab 2: Settings / Connection ---
  
  lv_obj_t* panel_set = lv_obj_create(tab2);
  lv_obj_set_size(panel_set, 440, 260); // Reduced width 460 -> 440
  lv_obj_center(panel_set);
  lv_obj_add_style(panel_set, &style_panel, LV_PART_MAIN); // Transparent/Glass logic handled in style
  // Override background specifically for this large container to be transparent if preferred, or keep dark panel
  lv_obj_set_style_bg_opa(panel_set, LV_OPA_0, LV_PART_MAIN); // Make it transparent to see global BG
  lv_obj_set_style_border_width(panel_set, 0, LV_PART_MAIN);
  lv_obj_clear_flag(panel_set, LV_OBJ_FLAG_SCROLLABLE);

  // Form Container
  lv_obj_t* form_cont = lv_obj_create(panel_set);
  lv_obj_set_size(form_cont, 420, 180); // Reduced width 440 -> 420
  lv_obj_align(form_cont, LV_ALIGN_TOP_MID, 0, 0);
  lv_obj_add_style(form_cont, &style_panel, LV_PART_MAIN);
  
  // SSID & PW
  ssid_ta = lv_textarea_create(form_cont);
  lv_obj_set_width(ssid_ta, 190);
  lv_textarea_set_one_line(ssid_ta, true);
  lv_textarea_set_placeholder_text(ssid_ta, "와이파이 이름");
  lv_obj_add_style(ssid_ta, &style_ta, LV_PART_MAIN);
  lv_obj_align(ssid_ta, LV_ALIGN_TOP_LEFT, 0, 0);

  pw_ta = lv_textarea_create(form_cont);
  lv_obj_set_width(pw_ta, 190);
  lv_textarea_set_one_line(pw_ta, true);
  lv_textarea_set_password_mode(pw_ta, true);
  lv_textarea_set_placeholder_text(pw_ta, "비밀번호");
  lv_obj_add_style(pw_ta, &style_ta, LV_PART_MAIN);
  lv_obj_align(pw_ta, LV_ALIGN_TOP_RIGHT, 0, 0);

  // Email & MQTT
  email_ta = lv_textarea_create(form_cont);
  lv_obj_set_size(email_ta, 190, 40);
  lv_textarea_set_one_line(email_ta, true);
  lv_textarea_set_placeholder_text(email_ta, "이메일");
  lv_obj_add_style(email_ta, &style_ta, LV_PART_MAIN);
  lv_obj_align(email_ta, LV_ALIGN_TOP_LEFT, 0, 50);

  mqtt_ta = lv_textarea_create(form_cont);
  lv_obj_set_size(mqtt_ta, 190, 40);
  lv_textarea_set_one_line(mqtt_ta, true);
  lv_textarea_set_placeholder_text(mqtt_ta, "MQTT 주소");
  lv_textarea_set_text(mqtt_ta, "mqtt.i2r.link");
  lv_obj_add_style(mqtt_ta, &style_ta, LV_PART_MAIN);
  lv_obj_align(mqtt_ta, LV_ALIGN_TOP_RIGHT, 0, 50);

  // Action Buttons Row
  lv_obj_t* act_row = lv_obj_create(panel_set);
  lv_obj_set_size(act_row, 420, 60); // Reduced width 440 -> 420
  lv_obj_align(act_row, LV_ALIGN_BOTTOM_MID, 0, 0);
  lv_obj_set_style_bg_opa(act_row, LV_OPA_TRANSP, LV_PART_MAIN);
  lv_obj_set_style_border_width(act_row, 0, LV_PART_MAIN);
  lv_obj_set_flex_flow(act_row, LV_FLEX_FLOW_ROW);
  lv_obj_set_flex_align(act_row, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
  lv_obj_clear_flag(act_row, LV_OBJ_FLAG_SCROLLABLE);

  // Manual Btn
  manual_btn = lv_btn_create(act_row);
  lv_obj_set_size(manual_btn, 100, 40);
  lv_obj_add_style(manual_btn, &style_btn_default, LV_PART_MAIN); // Grey style
  lv_obj_t* l1 = lv_label_create(manual_btn); lv_label_set_text(l1, "사용법"); lv_obj_center(l1);
  
  // Connect Btn (Primary)
  connect_btn = lv_btn_create(act_row);
  lv_obj_set_size(connect_btn, 100, 40);
  lv_obj_add_style(connect_btn, &style_btn_checked, LV_PART_MAIN); // Blue style
  lv_obj_t* l2 = lv_label_create(connect_btn); lv_label_set_text(l2, "연결"); lv_obj_center(l2);

  // BT Btn
  bt_btn = lv_btn_create(act_row);
  lv_obj_set_size(bt_btn, 100, 40);
  lv_obj_add_style(bt_btn, &style_btn_default, LV_PART_MAIN);
  lv_obj_t* l3 = lv_label_create(bt_btn); lv_label_set_text(l3, "블루투스"); lv_obj_center(l3);

  // Firmware Btn (Placed Absolute or in row?) 
  // User had FW button above Connect. Let's put it in the row or as an icon.
  // Let's add it to the row for modern look.
  fw_btn = lv_btn_create(act_row);
  lv_obj_set_size(fw_btn, 80, 40);
  lv_obj_add_style(fw_btn, &style_btn_default, LV_PART_MAIN);
  lv_obj_t* l4 = lv_label_create(fw_btn); lv_label_set_text(l4, "펌웨어"); lv_obj_center(l4);
  
  // MAC Label
  mac_label = lv_label_create(form_cont); // Put inside form container at bottom
  lv_label_set_text(mac_label, "MAC: ----");
  lv_obj_set_style_text_color(mac_label, COL_TXT_SUB, 0);
  lv_obj_align(mac_label, LV_ALIGN_BOTTOM_LEFT, 0, -10);


  // Event Callbacks
  auto qr_event = [](lv_event_t* e) { show_qr_panel("https://youtu.be/eMnKAh1EjlE", tab2); };
  lv_obj_add_event_cb(manual_btn, qr_event, LV_EVENT_CLICKED, NULL);

  lv_obj_add_event_cb(connect_btn, [](lv_event_t* e) {
    // Send Serial command
    const char* email = lv_textarea_get_text(email_ta);
    const char* ssid = lv_textarea_get_text(ssid_ta);
    const char* password = lv_textarea_get_text(pw_ta);
    const char* mqtt = lv_textarea_get_text(mqtt_ta);
    JsonDocument doc; doc["c"] = "si"; doc["e"] = email; doc["ssid"] = ssid;
    doc["password"] = password; doc["mqttBroker"] = mqtt;
    String json; serializeJson(doc, json); Serial1.println(json);
  }, LV_EVENT_CLICKED, NULL);

  lv_obj_add_event_cb(bt_btn, [](lv_event_t* e) { send_bleboot(); }, LV_EVENT_CLICKED, NULL);

  lv_obj_add_event_cb(fw_btn, [](lv_event_t* e) {
    JsonDocument doc; doc["c"] = "df"; doc["f"] = "i2r-02-hmi.ino.bin";
    String json; serializeJson(doc, json); Serial1.println(json);
  }, LV_EVENT_CLICKED, NULL);

  // Keyboard Handling
  lv_obj_t* kb = lv_keyboard_create(tab2);
  lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);
  lv_obj_align(kb, LV_ALIGN_BOTTOM_MID, 0, 0);
  // Force default font for keyboard to fix broken symbols
  lv_obj_set_style_text_font(kb, &lv_font_montserrat_20, LV_PART_MAIN); 
  lv_obj_set_style_text_font(kb, &lv_font_montserrat_20, LV_PART_ITEMS);

  auto kb_event_cb = [](lv_event_t* e) {
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t* ta = lv_event_get_target(e);
    lv_obj_t* kb = (lv_obj_t*)lv_event_get_user_data(e);
    if (code == LV_EVENT_FOCUSED || code == LV_EVENT_CLICKED) {
      lv_keyboard_set_textarea(kb, ta);
      lv_obj_clear_flag(kb, LV_OBJ_FLAG_HIDDEN);
      // Hide buttons to make space
      lv_obj_add_flag(connect_btn, LV_OBJ_FLAG_HIDDEN);
      lv_obj_add_flag(manual_btn, LV_OBJ_FLAG_HIDDEN);
      lv_obj_add_flag(bt_btn, LV_OBJ_FLAG_HIDDEN);
      lv_obj_add_flag(fw_btn, LV_OBJ_FLAG_HIDDEN);
      if (mac_label) lv_obj_add_flag(mac_label, LV_OBJ_FLAG_HIDDEN); // Added MAC hiding
    }
  };
  lv_obj_add_event_cb(ssid_ta, kb_event_cb, LV_EVENT_ALL, kb);
  lv_obj_add_event_cb(pw_ta, kb_event_cb, LV_EVENT_ALL, kb);
  lv_obj_add_event_cb(email_ta, kb_event_cb, LV_EVENT_ALL, kb);
  lv_obj_add_event_cb(mqtt_ta, kb_event_cb, LV_EVENT_ALL, kb);

  lv_obj_add_event_cb(kb, [](lv_event_t* e) {
    lv_event_code_t code = lv_event_get_code(e);
    lv_obj_t* kb = lv_event_get_target(e);
    if (code == LV_EVENT_CANCEL || code == LV_EVENT_READY) {
      lv_obj_add_flag(kb, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(connect_btn, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(manual_btn, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(bt_btn, LV_OBJ_FLAG_HIDDEN);
      lv_obj_clear_flag(fw_btn, LV_OBJ_FLAG_HIDDEN);
      if (mac_label) lv_obj_clear_flag(mac_label, LV_OBJ_FLAG_HIDDEN);
    }
  }, LV_EVENT_ALL, NULL);


  // --- Tab 3: Manuals (List Style) ---
  lv_obj_t* list_cont = lv_obj_create(tab3);
  lv_obj_set_size(list_cont, 440, 260);
  lv_obj_center(list_cont);
  lv_obj_add_style(list_cont, &style_panel, LV_PART_MAIN);
  lv_obj_set_flex_flow(list_cont, LV_FLEX_FLOW_ROW_WRAP); // Changed to GRID
  lv_obj_set_style_pad_gap(list_cont, 15, 0);

  // i2r-02 specific links/titles
  const char* titles[] = {
      "기기연결/로그인", "타이머 설정", "입력 트리거", 
      "센서 트리거", "Github 메뉴얼", "아이티알 홈", "HMI 한글폰트 설치"
  };
  const char* urls[] = {
      "https://youtu.be/o17IrUawetg", 
      "https://youtu.be/hlbH4OiEDu4", 
      "https://youtu.be/e6tqkVcQ8n0", 
      "https://youtu.be/hOzujluNKDU", 
      "https://github.com/kdi6033/i2r-02",
      "https://i2r.link",
      "https://github.com/kdi6033/i2r#4-lvgl-%ED%95%9C%EA%B8%80-%ED%8F%B0%ED%8A%B8-%EC%A0%81%EC%9A%A9-%EA%B0%80%EC%9D%B4%EB%93%9C"
  };

  for(int i=0; i<7; i++) {
      lv_obj_t* btn_link = lv_btn_create(list_cont);
      lv_obj_set_width(btn_link, 190); // Reduced width to half
      lv_obj_add_style(btn_link, &style_btn_default, LV_PART_MAIN);
      lv_obj_t* l = lv_label_create(btn_link);
      lv_label_set_text(l, titles[i]);
      lv_obj_center(l);
      
      lv_obj_add_event_cb(btn_link, [](lv_event_t* e) {
         const char* url = (const char*)lv_event_get_user_data(e);
         show_qr_panel(url, tab3);
      }, LV_EVENT_CLICKED, (void*)urls[i]);
  }
}

// QR Panel Implementation
void show_qr_panel(const char* url, lv_obj_t* parent) {
  if (qr_panel) lv_obj_del(qr_panel); // Delete existing if any

  qr_panel = lv_obj_create(parent);
  lv_obj_set_size(qr_panel, 400, 240); // Adjusted height
  lv_obj_center(qr_panel);
  lv_obj_set_style_bg_color(qr_panel, COL_BG, LV_PART_MAIN);
  lv_obj_set_style_border_color(qr_panel, COL_PRIMARY, LV_PART_MAIN);
  lv_obj_set_style_border_width(qr_panel, 2, LV_PART_MAIN);
  lv_obj_set_style_radius(qr_panel, 12, LV_PART_MAIN);

  lv_obj_t* qr = lv_qrcode_create(qr_panel, 180, lv_color_white(), lv_color_black());
  lv_qrcode_update(qr, url, strlen(url));
  lv_obj_align(qr, LV_ALIGN_LEFT_MID, 20, 0); // Left

  lv_obj_t* close_btn = lv_btn_create(qr_panel);
  lv_obj_set_size(close_btn, 100, 40);
  lv_obj_align(close_btn, LV_ALIGN_RIGHT_MID, -20, 0); // Right
  lv_obj_add_style(close_btn, &style_btn_default, LV_PART_MAIN);
  
  lv_obj_t* l = lv_label_create(close_btn);
  lv_label_set_text(l, "닫기");
  lv_obj_center(l);

  lv_obj_add_event_cb(close_btn, [](lv_event_t* e) {
    lv_obj_del(qr_panel);
    qr_panel = NULL;
  }, LV_EVENT_CLICKED, NULL);
}

void setup() {
  delay(1000); // Increased safe delay
  Serial.begin(115200);
  Serial1.setTX(0); Serial1.setRX(1);
  Serial1.begin(9600);
  delay(100);
  Serial1.println("INIT");
  serialBuffer.reserve(256);

  Wire.setSDA(20); Wire.setSCL(21); Wire.begin();

  tft.begin(); tft.setRotation(1);
  uint16_t calData[5] = {192, 3590, 335, 3362, 1};
  tft.setTouch(calData);
  tft.fillScreen(TFT_BLACK);

  lv_init();
  lv_disp_draw_buf_init(&draw_buf, buf1, NULL, SCREEN_WIDTH * SCREEN_HEIGHT / 10);
  static lv_disp_drv_t disp_drv;
  lv_disp_drv_init(&disp_drv);
  disp_drv.hor_res = SCREEN_WIDTH;
  disp_drv.ver_res = SCREEN_HEIGHT;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;
  lv_disp_drv_register(&disp_drv);

  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);

  create_tabs();
}

void loop() {
  lv_timer_handler();
  delay(5);

  while (Serial1.available()) {
    char c = Serial1.read();
    if (c == '\n') {
      serialBuffer.trim();
      if (serialBuffer.length() > 0) {
        parseJSONPayload((byte*)serialBuffer.c_str(), serialBuffer.length());
      }
      serialBuffer = "";
      serialBuffer = "";
    } else {
      if (serialBuffer.length() < 256) serialBuffer += c;
    }
  }
}

void parseJSONPayload(byte* payload, unsigned int length) {
  Serial.println((const char*)payload);
  JsonDocument doc;
  DeserializationError error = deserializeJson(doc, payload, length);
  if (error) {
    Serial.println("JSON Error");
    return;
  }

  if (doc["c"] == "ti") {
    JsonArray outArray = doc["out"];
    for (int i = 0; i < 4 && i < outArray.size(); i++) {
      bool newState = outArray[i];
      if (btnState[i] != newState) {
        btnState[i] = newState;
        updateButtonUI(i, btnState[i]);
      }
    }
  }

  JsonArray inArray = doc["in"];
  if (!inArray.isNull()) {
    for (int i = 0; i < 4 && i < inArray.size(); i++) {
      bool newState = inArray[i];
      if (ledState[i] != newState) {
         ledState[i] = newState;
         updateInputLedUI(i, newState); 
      }
    }
  }

  bool wifiStatus = doc["wifi"] | false;
  if(wifiStatus) lv_obj_set_style_text_color(wifi_icon, COL_SUCCESS, 0); 
  else lv_obj_set_style_text_color(wifi_icon, COL_OFF, 0);

  bool mqttStatus = doc["mqtt"] | false;
  if(mqttStatus) lv_obj_set_style_text_color(mqtt_icon, COL_SUCCESS, 0);
  else lv_obj_set_style_text_color(mqtt_icon, COL_OFF, 0);

  if (!doc["mac"].isNull() && mac_label) {
     const char* mac = doc["mac"];
     lv_label_set_text_fmt(mac_label, "MAC: %s", mac);
  }
}
