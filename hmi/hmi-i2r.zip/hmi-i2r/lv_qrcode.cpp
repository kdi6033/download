#include "lv_qrcode.hpp"
#include <cstdlib>
#include <cstring>
#include <lvgl.h>

/* Arduino QRCode 라이브러리 (Richard Moore) 사용 */
#include <qrcode.h>

static lv_color_t saved_dark_color;
static lv_color_t saved_light_color;
static lv_coord_t saved_canvas_size = 150; /* my_qrcode_create에서 저장 */

static void draw_qr(lv_obj_t *canvas, QRCode *qrcode) {
  lv_canvas_fill_bg(canvas, saved_light_color, LV_OPA_COVER);

  /* lv_obj_get_width는 레이아웃 전엔 0 반환 → saved_canvas_size 직접 사용 */
  uint8_t qr_modules = qrcode->size; // version5 → 37
  uint8_t scale = (uint8_t)(saved_canvas_size / qr_modules);
  if (scale < 1)
    scale = 1;

  for (uint8_t y = 0; y < qr_modules; y++) {
    for (uint8_t x = 0; x < qr_modules; x++) {
      /* qrcode_getModule returns true for dark (black) modules */
      if (qrcode_getModule(qrcode, x, y)) {
        for (uint8_t yy = 0; yy < scale; yy++) {
          for (uint8_t xx = 0; xx < scale; xx++) {
            lv_canvas_set_px(canvas, x * scale + xx, y * scale + yy,
                             saved_dark_color, LV_OPA_COVER);
          }
        }
      }
    }
  }
}

lv_res_t my_qrcode_update(lv_obj_t *canvas, const void *data,
                          uint32_t data_len) {
  /* ricmoo 라이브러리: version 5 (37x37), ECC_LOW 이면 URL 길이 정도 수용 가능
   */
  uint8_t version = 5;
  uint16_t bufSize = qrcode_getBufferSize(version);
  uint8_t *modules = (uint8_t *)malloc(bufSize);
  if (!modules)
    return LV_RES_INV;

  QRCode qrcode;
  int8_t ok;

  if (data_len > 0 && ((const char *)data)[data_len - 1] == '\0') {
    /* 문자열로 해석 (널 종료) */
    ok =
        qrcode_initText(&qrcode, modules, version, ECC_LOW, (const char *)data);
  } else {
    /* 바이너리 */
    ok = qrcode_initBytes(&qrcode, modules, version, ECC_LOW,
                          (uint8_t *)const_cast<void *>(data),
                          (uint16_t)data_len);
  }

  if (ok < 0) {
    free(modules);
    return LV_RES_INV;
  }

  draw_qr(canvas, &qrcode);
  free(modules);
  return LV_RES_OK;
}

lv_obj_t *my_qrcode_create(lv_obj_t *parent, lv_coord_t size,
                           lv_color_t dark_color, lv_color_t light_color) {
  saved_dark_color = dark_color;
  saved_light_color = light_color;
  saved_canvas_size = size; /* draw_qr에서 scale 계산에 사용 */

  lv_obj_t *canvas = lv_canvas_create(parent);

  static lv_color_t buf[200 * 200]; /* 200x200 = 80KB, RP2040 RAM 안전 */

  /* LVGL v9: use color format enum instead of LV_IMG_CF_TRUE_COLOR */
  lv_canvas_set_buffer(canvas, buf, size, size, LV_COLOR_FORMAT_NATIVE);
  lv_obj_set_size(canvas, size, size);
  lv_canvas_fill_bg(canvas, light_color, LV_OPA_COVER);

  return canvas;
}