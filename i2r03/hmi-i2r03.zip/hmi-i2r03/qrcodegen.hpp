#pragma once

#include <cstdint>
#include <cstddef>

/* 오류 정정 수준 (Error Correction Level) */
enum class qrcodegen_Ecc : uint8_t {
    LOW = 0,
    MEDIUM,
    QUARTILE,
    HIGH
};

/* 마스크 패턴 */
enum class qrcodegen_Mask : int8_t {
    AUTO = -1,
    M0 = 0,
    M1,
    M2,
    M3,
    M4,
    M5,
    M6,
    M7
};

/* 인코딩 모드 */
enum class qrcodegen_Mode : uint8_t {
    NUMERIC      = 0x1,
    ALPHANUMERIC = 0x2,
    BYTE         = 0x4,
    KANJI        = 0x8,
    ECI          = 0x7  // Extended Channel Interpretation
};

/* QR 코드 세그먼트 구조체 */
struct qrcodegen_Segment {
    qrcodegen_Mode mode;
    int numChars;
    uint8_t* data;
    int bitLength;
};

/* QR 코드 버전 관련 상수 */
constexpr int qrcodegen_VERSION_MIN = 1;
constexpr int qrcodegen_VERSION_MAX = 40;
constexpr int qrcodegen_BUFFER_LEN_FOR_VERSION(int n) {
    return (((n * 4 + 17) * (n * 4 + 17) + 7) / 8 + 1);
}
constexpr int qrcodegen_BUFFER_LEN_MAX = qrcodegen_BUFFER_LEN_FOR_VERSION(qrcodegen_VERSION_MAX);

/* 인코딩 함수 */
bool qrcodegen_encodeText(const char* text, uint8_t tempBuffer[], uint8_t qrcode[],
    qrcodegen_Ecc ecl, int minVersion, int maxVersion, qrcodegen_Mask mask, bool boostEcl);

bool qrcodegen_encodeBinary(uint8_t dataAndTemp[], size_t dataLen, uint8_t qrcode[],
    qrcodegen_Ecc ecl, int minVersion, int maxVersion, qrcodegen_Mask mask, bool boostEcl);

/* 세그먼트 인코딩 (고급용) */
bool qrcodegen_encodeSegments(const qrcodegen_Segment segs[], size_t len,
    qrcodegen_Ecc ecl, uint8_t tempBuffer[], uint8_t qrcode[]);

bool qrcodegen_encodeSegmentsAdvanced(const qrcodegen_Segment segs[], size_t len,
    qrcodegen_Ecc ecl, int minVersion, int maxVersion, qrcodegen_Mask mask, bool boostEcl,
    uint8_t tempBuffer[], uint8_t qrcode[]);

/* 문자열이 알파뉴메릭 또는 숫자인지 검사 */
bool qrcodegen_isAlphanumeric(const char* text);
bool qrcodegen_isNumeric(const char* text);

/* 세그먼트 크기 계산 */
size_t qrcodegen_calcSegmentBufferSize(qrcodegen_Mode mode, size_t numChars);

/* 세그먼트 생성 */
qrcodegen_Segment qrcodegen_makeBytes(const uint8_t data[], size_t len, uint8_t buf[]);
qrcodegen_Segment qrcodegen_makeNumeric(const char* digits, uint8_t buf[]);
qrcodegen_Segment qrcodegen_makeAlphanumeric(const char* text, uint8_t buf[]);
qrcodegen_Segment qrcodegen_makeEci(long assignVal, uint8_t buf[]);

/* QR 코드 해석 */
int  qrcodegen_getSize(const uint8_t qrcode[]);
bool qrcodegen_getModule(const uint8_t qrcode[], int x, int y);
