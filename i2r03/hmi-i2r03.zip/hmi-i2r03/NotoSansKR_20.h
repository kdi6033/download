#ifndef NOTOSANSKR_20_H
#define NOTOSANSKR_20_H

#include "lvgl.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const lv_font_t NotoSansKR_20;

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
