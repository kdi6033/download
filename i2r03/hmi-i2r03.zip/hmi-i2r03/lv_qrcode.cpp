#include <lvgl.h>
#include <cstdlib>
#include <cstring>
#include "lv_qrcode.hpp"
#include "qrcodegen.hpp"

static void draw_qr(lv_obj_t* canvas, const uint8_t* data, uint32_t size) {
    const lv_color_t c_black = lv_color_black();
    const lv_color_t c_white = lv_color_white();

    lv_canvas_fill_bg(canvas, c_white, LV_OPA_COVER);

    for (int y = 0; y < static_cast<int>(size); y++) {
        for (int x = 0; x < static_cast<int>(size); x++) {
            if (qrcodegen_getModule(data, x, y)) {
                lv_draw_rect_dsc_t rect_dsc;
                lv_draw_rect_dsc_init(&rect_dsc);
                rect_dsc.bg_color = c_black;
                rect_dsc.bg_opa = LV_OPA_COVER;
                lv_canvas_draw_rect(canvas, x, y, 1, 1, &rect_dsc);
            }
        }
    }
}

lv_res_t my_qrcode_update(lv_obj_t* canvas, void* data, uint32_t data_len) {
    uint8_t temp[qrcodegen_BUFFER_LEN_MAX];
    uint8_t qr_data[qrcodegen_BUFFER_LEN_MAX];

    bool ok = qrcodegen_encodeBinary(
        static_cast<uint8_t*>(data), data_len, qr_data,
        qrcodegen_Ecc::LOW, qrcodegen_VERSION_MIN, qrcodegen_VERSION_MAX,
        qrcodegen_Mask::AUTO, true
    );

    if (!ok) return LV_RES_INV;

    draw_qr(canvas, qr_data, qrcodegen_getSize(qr_data));
    return LV_RES_OK;
}

lv_obj_t* my_qrcode_create(lv_obj_t* parent, lv_coord_t size, lv_color_t dark_color, lv_color_t light_color) {
    lv_obj_t* canvas = lv_canvas_create(parent);

    static lv_color_t buf[LV_CANVAS_BUF_SIZE_TRUE_COLOR(256, 256)];
    lv_canvas_set_buffer(canvas, buf, size, size, LV_IMG_CF_TRUE_COLOR);
    lv_obj_set_size(canvas, size, size);
    lv_canvas_fill_bg(canvas, light_color, LV_OPA_COVER);

    return canvas;
}
