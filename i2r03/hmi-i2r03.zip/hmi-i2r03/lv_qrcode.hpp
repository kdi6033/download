#pragma once

#include <lvgl.h>
#include <stdint.h>
#include "qrcodegen.hpp"

// QR 코드용 캔버스 생성
lv_obj_t *my_qrcode_create(lv_obj_t *parent, lv_coord_t size, lv_color_t dark_color, lv_color_t light_color);

// QR 코드 갱신
lv_res_t my_qrcode_update(lv_obj_t *canvas, const void *data, uint32_t data_len);
