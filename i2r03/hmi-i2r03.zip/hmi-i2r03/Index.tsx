import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { Features } from '@/components/Features';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-dark">
      <Navbar />
      <Hero />
      <Features />
      
      <section id="docs" className="py-24 border-t border-border/50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Documentation Coming Soon</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Complete API documentation and integration guides will be available here.
            Connect your MQTT/REST backend seamlessly.
          </p>
        </div>
      </section>

      <footer className="py-8 border-t border-border/50">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>&copy; 2024 i2r.link. AI Science Platform.</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
